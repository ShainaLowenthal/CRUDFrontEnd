import React, {Component} from 'react';

class ZipData extends Component
{
  render()
  {
    let{
      Zipcode,
      City,
      State,
      WorldRegion,
      Country,
      EstimatedPopulation,
      TotalWages,
    } = this.props.data;
    
    return (
      <div align = "left">
        <p className = "inline">zip: {Zipcode}</p> <br/>
        <p className = "inline">city: {City}</p> <br/>
        <p className = "inline">state: {State}</p> <br/>
        <p className = "inline">world region: {WorldRegion}</p> <br/>
        <p className = "inline">county: {Country}</p> <br/>
        <p className = "inline">population: {EstimatedPopulation}</p> <br/>
        <p className = "inline">wage: {TotalWages}</p>
      </div>
    );
  }
}

export default ZipData;
