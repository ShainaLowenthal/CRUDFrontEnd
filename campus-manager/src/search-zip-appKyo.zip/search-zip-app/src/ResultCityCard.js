import React, {Component} from 'react';
import axios from 'axios';
import './ResultCityCard.css';

class ResultCityCard extends Component
{
  constructor(props)
  {
    super(props);
    this.state =
    {
      result : "",
      inputAddress_ : 'http://ctp-zip-api.herokuapp.com/city/',
      data:[]
    };
  }

  fetchZipData()
  {
    axios.get(this.state.inputAddress_ + this.props.inputCity).then(response =>
    {
      const result = response.data
      this.setState({data: result, result:""});
      console.log(result);
    }).catch(err => console.log(err), this.setState({result: "Not Found"}));
  }

  componentDidUpdate (prevProps)
  {
     if (prevProps.inputCity !== this.props.inputCity) {
      this.fetchZipData();
    }
  }

  render()
  {
    return(
    <div className="center">
      <div className = "flexContainer scroll">
      {this.state.data.map(cityzip => (<li className = "resultCityBox">{cityzip}</li>))}
      </div>
    </div>
    );
  }
}
export default ResultCityCard;
