import React, {Component} from 'react';
// import axios from 'axios';
import './App.css';
import ResultZipCard from './ResultZipCard'
import ResultCityCard from './ResultCityCard'
import ResultGiphyCard from './ResultGiphyCard'
// <div className="onoffswitch">
//   <form>
//     <input type="checkbox" name="onoffswitch" className="onoffswitch-checkbox" id="myonoffswitch" defaultChecked />
//     <label className="onoffswitch-label" htmlFor="myonoffswitch">
//       <span className="onoffswitch-inner"></span>
//       <span className="onoffswitch-switch"></span>
//     </label>
//   </form>
// </div>
class App extends Component
{
  constructor(props)
  {
    super(props)
    this.state =
    {
      inputZip_: 0,
      inputZipHolder_: "",
      inputCity_: "",
      inputCityHolder_ : "",
      inputGIPHY_:"",
      inputGIPHYHolder_:"",
    }
  }
  getInputGIPHY = (event) =>
  {
    this.setState({ inputGIPHYHolder_: event.target.value })
  }

  getInputZip = (event) =>
  {
    this.setState({ inputZipHolder_: event.target.value })
  }

  getInputCity = (event) =>
  {
    this.setState({ inputCityHolder_: event.target.value })
  }
  btnGIPHYSearch = () =>
  {
    this.setState((state) => ({ inputGIPHY_: state.inputGIPHYHolder_ }) )
  }
  btnZipSearch = () =>
  {
    this.setState((state) => ({ inputZip_: state.inputZipHolder_ }) )
  }

  btnCitySearch = () =>
  {
    this.setState((state) => ({ inputCity_: state.inputCityHolder_.toUpperCase() }) )
  }

  render()
  {
    return(
    <div className="center"> {/*main DIV*/}
      <div className="center header">
        <h2>Seach APP </h2>
      </div>{/*HEADER END---*/}

      {/*CenterBox------------------------------------------------*/}
      <div className = "center searchBox">
        {/*GIPHY------------------------------------------------*/}
        <b> GIPHY: </b>
        <input value = {this.state.inputGIPHYHolder_} onChange = {this.getInputGIPHY} placeholder = "Type Giphy Here"/>
        <button onClick = {this.btnGIPHYSearch}> SEARCH</button>
        <div className ="horizontalScroll">
          <ResultGiphyCard inputGIPHY = {this.state.inputGIPHY_}/>
        </div>
        {/*ZIPCODE------------------------------------------------*/}
        <b> Zip Code: </b>
        <input value = {this.state.inputZipHolder_} onChange = {this.getInputZip} placeholder = "Type Zipcode Here"/>
        <button onClick = {this.btnZipSearch}> SEARCH</button>
        <ResultZipCard inputZip = {this.state.inputZip_}/>
        {/*CITYNAME------------------------------------------------*/}
        <b> City Name: </b>
        <input value = {this.state.inputCityHolder_} onChange = {this.getInputCity} placeholder = "Type City Name Here"/>
        <button onClick = {this.btnCitySearch}> SEARCH</button>
        <ResultCityCard inputCity = {this.state.inputCity_}/>
      </div>{/*Center Box END*/}
    </div>//{/*<main DIV END>*/}
    );
  }
}

export default App;
